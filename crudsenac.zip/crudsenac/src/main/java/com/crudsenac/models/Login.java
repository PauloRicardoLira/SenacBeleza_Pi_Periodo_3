package com.crudsenac.models;

public class Login {

	
	
}
