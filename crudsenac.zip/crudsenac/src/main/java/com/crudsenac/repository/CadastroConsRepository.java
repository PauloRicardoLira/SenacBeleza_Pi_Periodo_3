package com.crudsenac.repository;

import org.springframework.data.repository.CrudRepository;
import com.crudsenac.models.CadastroConsultor;

public interface CadastroConsRepository extends CrudRepository<CadastroConsultor, String>{

}