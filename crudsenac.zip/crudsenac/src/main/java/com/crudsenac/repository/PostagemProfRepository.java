package com.crudsenac.repository;

import org.springframework.data.repository.CrudRepository;
import com.crudsenac.models.PostagemProfessor;

public interface PostagemProfRepository extends CrudRepository<PostagemProfessor, String>{

}
