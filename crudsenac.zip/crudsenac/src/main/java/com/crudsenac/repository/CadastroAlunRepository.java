package com.crudsenac.repository;

import org.springframework.data.repository.CrudRepository;
import com.crudsenac.models.CadastroAluno;

public interface CadastroAlunRepository extends CrudRepository<CadastroAluno, String>{

}