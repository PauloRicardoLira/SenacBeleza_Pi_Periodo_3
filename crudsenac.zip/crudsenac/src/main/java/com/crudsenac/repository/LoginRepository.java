package com.crudsenac.repository;

public interface LoginRepository{

}
