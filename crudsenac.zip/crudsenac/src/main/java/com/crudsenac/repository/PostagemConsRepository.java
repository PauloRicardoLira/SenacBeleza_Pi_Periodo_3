package com.crudsenac.repository;

import org.springframework.data.repository.CrudRepository;
import com.crudsenac.models.PostagemConsultor;

public interface PostagemConsRepository extends CrudRepository<PostagemConsultor, String>{

}
