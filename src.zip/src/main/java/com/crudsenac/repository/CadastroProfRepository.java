package com.crudsenac.repository;

import org.springframework.data.repository.CrudRepository;
import com.crudsenac.models.CadastroProfessor;

public interface CadastroProfRepository extends CrudRepository<CadastroProfessor, String>{

}